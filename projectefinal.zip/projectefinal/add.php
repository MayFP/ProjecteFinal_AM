<?php
//aixo serveix per agafar la imatge del directori temporal i posar-la al directori escollit.
    $upload_dir = 'C:\xampp\htdocs\projectefinal\assets\img';
    $dir_intern = 'assets/img';
    $photo_ruta = $_FILES['photo']['tmp_name'];
    $photo_name = $_FILES["photo"]["name"];
    $photo = "$upload_dir/$photo_name";
    $photo_bdd = "$dir_intern/$photo_name";
    move_uploaded_file($photo_ruta, $photo);

    //recuperacio de les dades del formulari
    $nom = $_POST["nom"];
    $desc = $_POST["desc"];
    $preu = $_POST["preu"];
    $talla = $_POST["talla"];
    $color = $_POST["color"];

    //fem la connexio a la bdd
    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        //contem quants registres en temim per recuperar el fil de id's que hi ha a la bdd
        $con = "SELECT * FROM producte;";
        $res = $connexio->query($con);

        $count = 0;
        $contador = 1;

        while($arrayConsulta = $res->fetch_array(MYSQLI_BOTH))
        {
            $contador++;
            $count = $contador;
        }

        //inserim el nou registre a la bdd
        echo "INSERT INTO producte (id_prod, nom, descripcio, preu, imatge, id_talla, id_color) VALUES ($count, '$nom', '$desc', $preu, '$photo_bdd', $talla, $color);";
        $consulta = "INSERT INTO producte (id_prod, nom, descripcio, preu, imatge, id_talla, id_color) VALUES ($count, '$nom', '$desc', $preu, '$photo_bdd', $talla, $color);";
        $resultat = $connexio->query($consulta);
        header('Location: store.php');
    }
?>