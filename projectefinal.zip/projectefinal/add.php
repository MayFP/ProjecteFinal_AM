<?php
    $upload_dir = 'C:\xampp\htdocs\projectefinal\assets\img';
    $dir_intern = 'assets/img';
    $photo_ruta = $_FILES['photo']['tmp_name'];
    $photo_name = $_FILES["photo"]["name"];
    $photo = "$upload_dir/$photo_name";
    $photo_bdd = "$dir_intern/$photo_name";
    move_uploaded_file($photo_ruta, $photo);

    $nom = $_POST["nom"];
    $desc = $_POST["desc"];
    $preu = $_POST["preu"];
    $talla = $_POST["talla"];
    $color = $_POST["color"];

    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        $con = "SELECT * FROM producte;";
        $res = $connexio->query($con);

        $count = 0;
        $contador = 1;

        while($arrayConsulta = $res->fetch_array(MYSQLI_BOTH))
        {
            $contador++;
            $count = $contador;
        }

        echo "INSERT INTO producte (id_prod, nom, descripcio, preu, imatge, id_talla, id_color) VALUES ($count, '$nom', '$desc', $preu, '$photo_bdd', $talla, $color);";
        $consulta = "INSERT INTO producte (id_prod, nom, descripcio, preu, imatge, id_talla, id_color) VALUES ($count, '$nom', '$desc', $preu, '$photo_bdd', $talla, $color);";
        $resultat = $connexio->query($consulta);
        header('Location: store.php');
    }
?>