<?php

    $id_u = $_GET["id_u"];
    $id_p = $_GET["id_p"];
    $quantitat = $_GET["quantitat"];

    echo $id_u.' '.$id_p.' '.$quantitat;

    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        $insertar = "INSERT INTO carro (id_user, id_prod, quantitat) VALUES ($id_u, $id_p, $quantitat);";
        $resultat = $connexio->query($insertar);
        $afegir = "UPDATE carro SET quantitat='$quantitat' WHERE id_user LIKE $id_u AND id_prod =  $id_p;";
        $resultat = $connexio->query($afegir);
    }

    echo '<script language="javascript">alert("Comanda afegida al carro!");window.location.href="producte.php?id='.$id_p.'";</script>';
?>