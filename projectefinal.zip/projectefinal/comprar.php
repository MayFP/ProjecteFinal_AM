<?php
    $id_u = $_COOKIE["id_u"];
    $id_compra = date('m/d/Y-h:i:s', time());

    echo $id_u;

    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");
    
    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        $consulta = "SELECT correu, nom FROM usuari WHERE id_user LIKE '$id_u';";
        $resultat = $connexio->query($consulta);
    }
    while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
    {
        $email = $arrayConsulta["correu"];
        $nom = $arrayConsulta["nom"];
        
        $missatge = "Estimat client amb usuari '.$nom.' la seva compra ha estat realitzada de forma satisfactòria.
            el teu identificador de comanda es el: '.$id_compra.' amb aquest identificador pot demanar informació.";
    }

    // require_once('../class.phpmailer.php');
    // $mail = new PHPMailer();

    // $body = ' 
    //     <html> 
    //         <head> 
    //             <title>Compra a la web RutesMoteres.com</title> 
    //         </head> 
    //         <body> 
    //             <h1>Hola '.$nom.'</h1> 
    //             <p>La seva compra ha estat realitzada de forma satisfactòria.
    //             El teu identificador de comanda es el: '.$id_compra.' amb aquest identificador pot demanar informació.</p>
    //         </body> 
    //     </html> 
    // ';

    // $mail>SetFrom('amontero.dam@institutcampalans.net', 'Alex Montero');
    // $mail>AddReplyTo('amontero.dam@institutcampalans.net', 'Alex Montero');
    // $address = $email;
    // $mail>AddAddress($address, $nom);
    // $mail>Subject = "Compra a la Web";
    // $mail>MsgHTML($body);
    // $mail>CharSet = "UTF8";
    // $mail>Encoding = "quotedprintable";

    // if(!$mail>Send())
    // {
    //     echo "Error al enviar el missatge: ".$mail>ErrorInfo;
    // }
    // else
    // {
    //     echo "Missatge enviat!";
    // }

    $desti = "amontero.dam@institutcampalans.net"; 
    $assumpte = "Compra a la Web"; 
    $cos = ' 
    <html> 
        <head> 
            <title>Compra a la web RutesMoteres.com</title> 
        </head> 
        <body> 
            <h1>Hola '.$nom.'</h1> 
            <p>La seva compra ha estat realitzada de forma satisfactòria.
            El teu identificador de comanda es el: '.$id_compra.' amb aquest identificador pot demanar informació.</p>
        </body> 
    </html> 
    ';

    $headers = "MIME-Version: 1.0\r\n"; 
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
    $headers .= "From: Alex Montero <amontero.dam@institutcampalans.net>\r\n";
    $headers .= "Reply-To: amontero.dam@institutcampalans.net\r\n";
    $headers .= "Return-path: amontero.dam@institutcampalans.net\r\n";
    $headers .= "Cc: amontero.dam@institutcampalans.net\r\n";
    $headers .= "Bcc: mferrer.dam@institutcampalans.net\r\n";

    mail($desti,$assumpte,$cos,$headers);

    $consulta = "DELETE FROM carro WHERE id_user LIKE '$id_u';";
    $resultat = $connexio->query($consulta);

    echo '<script language="javascript">alert("Has realitzat la teva comanda correctament! Revisa el teu correu!");window.location.href="carro.php";</script>';
?>
