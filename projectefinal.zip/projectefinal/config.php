<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="config.css">
    <title>Projecte Final</title>
    <script>
      function confirma()
      {
        if (confirm("Vols canviar aquestes dades?")==false)
        {
          return false;
        }
        else
        {
          return true;
        }
      }

      function eliminar()
      {
        if (confirm("Estas segur que vols eliminar aquest usuari?")==false)
        {
          return false;
        }
        else
        {
          return true;
        }
      }
    </script>
</head>
<body>
    <nav class="navbar navbar-expand-sm navbar-light">
        <img src="img/logo.png" class="d-inline-block align-top m-3 logo" alt="">
        <a class="navbar-brand" href="index.html">Rutes Moteres</a>
        <button class="navbar-toggler m-3" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" (click)="isShown = !isShown">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" [ngClass]="{'show': isShown}" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" (click)="isShown = false" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="rutes.php">Rutes</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" (click)="isShown = false" href="memories.php">Memories</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="info.php">Info Ruta</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="store.php">Store</a>
            </li>
          </ul>
        </div>
        <a class="nav-link" (click)="isShown = false" href="carro.php">🛒</a>
        <a class="nav-link" (click)="isShown = false" href="config.php">⚙️</a>
        <a class="nav-link" (click)="isShown = false" href="form.html">👤</a>
    </nav>

    <div class="container">
        <?php

          $id_u = $_COOKIE["id_u"];

          if($id_u == null)
          {
            echo "null!";
            header('Location: form.html');
          }

            $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");
    
            if($connexio->connect_error)
            {
              echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
              $connexio->close();
            }
            else
            {
              $consulta = "SELECT nom, password, correu, imatge FROM usuari WHERE id_user LIKE '$id_u';";
              $resultat = $connexio->query($consulta);
            }

            while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
            {
              $nom = $arrayConsulta["nom"];
              $password = $arrayConsulta["password"];
              $email = $arrayConsulta["correu"];
              $imatge = $arrayConsulta["imatge"];
            }
            echo '
                <div class="form">
                  <h4>Canviar dades personals</h4>
                    <form action="editar.php" role="form" method="POST" enctype="multipart/form-data">
                        <label>Nom d\'ususari antic: '.$nom.'</label><br>
                        <label>Entra el nou nom</label><br>
                        <input type="text" name="nom" placeholder="Nom"><br><br>
                        <label>Correu electrónic antic: '.$email.'</label><br>
                        <label>Entra el nou correu</label><br>
                        <input type="text" name="correu" placeholder="Correu"><br><br>
                        <label>Contrassenya antiga: '.strlen($password).' caracters</label><br>
                        <label>Entra la nova contrassenya</label><br>
                        <input type="password" name="password" placeholder="Contrassenya"><br><br>
                        <label>Foto antiga: <br> <img src="'.$imatge.'"></label><br>
                        <label>Entra la nova foto</label><br>
                        <input type="file" id="customFileLang" name="photo" lang="es" required><br><br>
                        <input type="submit" value="Canviar dades" onclick="return confirma(this)">
                    </form>
                </div>
                <br>
            ';

            if($id_u == 'admin')
            {
              echo '<h4>Eliminar usuaris de la web</h4>';

              $consulta = "SELECT id_user, nom, password, correu FROM usuari;";
              $resultat = $connexio->query($consulta);

              echo '<table class="table table-bordered table-striped">
              <tr>
                  <td><b>ID</b></td>
                  <td><b>Usuari</b></td>
                  <td><b>Contrasenya</b></td>
                  <td><b>Correu</b></td>
              </tr>';
              while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
              {
                $id_user = $arrayConsulta["id_user"];
                $nom = $arrayConsulta["nom"];
                $password = $arrayConsulta["password"];
                $email = $arrayConsulta["correu"];

                echo'<tr>
                <td>'.$id_user.'</td>
                <td>'.$nom.'</td>
                <td>'.$password.'</td>
                <td>'.$email.'</td>
            </tr>';
              }
              echo '</table>';
              echo '
              <form action="eliminar_usuari.php" role="form" method="POST" enctype="multipart/form-data">
                <label>Entra el ID del usuari a eliminar</label>
                <input type="text" name="id_user" placeholder="ID"><br><br>
                <input type="submit" value="Eliminar" onclick="return eliminar(this)">
              </form>
              ';


              // $consulta = "DELETE FROM usuari WHERE id_user LIKE '$id_entrat';";
              // $resultat = $connexio->query($consulta);

            }
        ?>
    </div>
    <div class="contain">
        <div class="banner">
            <p>©Rutes Moteres. Tots els drets reservats - Alex Montero i Maria Ferrer. </p>
        </div>
        <div class="links">
            <a href="https://t.me/+D4mgYwsk4_JjOTc0"><img src="img/telegram.png" class="telegram"></a>
            <a href="https://twitter.com/"><img src="img/twitter.png"  class="twitter"></a>
            <a href="https://www.facebook.com/"><img src="img/facebook.png" class="facebook"></a>
            <a href="https://www.instagram.com/"><img src="img/instagram.png" class="instagram"></a>
        </div>
    </div>
</body>
</html>