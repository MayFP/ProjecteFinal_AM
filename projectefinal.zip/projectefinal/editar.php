<?php
    $id = $_COOKIE["id_u"];
    $upload_dir = 'C:\xampp\htdocs\projectefinal\img';
    $dir_intern = 'img';
    $email = $_POST["correu"];
    $password = $_POST["password"];
    $nom = $_POST["nom"];
    $photo_ruta = $_FILES['photo']['tmp_name'];
    $photo_name = $_FILES["photo"]["name"];
    $photo = "$upload_dir/$photo_name";
    $photo_bdd = "$dir_intern/$photo_name";
    $espotafegir = false;

    move_uploaded_file($photo_ruta, $photo);

    echo "UPDATE usuari SET id_user = '$id', nom = '$nom', correu = '$email', password = '$password', imatge = '$photo_bdd';";

    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        $consulta = "UPDATE usuari SET nom = '$nom', correu = '$email', password = '$password', imatge = '$photo_bdd' WHERE id_user LIKE '$id';";
        $resultat = $connexio->query($consulta);
        header('Location: config.php');
    }
?>