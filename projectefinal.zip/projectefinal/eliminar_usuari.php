<?php
    $id_user = $_POST["id_user"];

    // echo $id_user;

    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");
    
    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        $consulta = "DELETE FROM usuari WHERE id_user LIKE '$id_user';";
        $resultat = $connexio->query($consulta);
    }

    echo '<script language="javascript">alert("S\'ha eliminat l\'usuari correctament");window.location.href="config.php";</script>';
?>