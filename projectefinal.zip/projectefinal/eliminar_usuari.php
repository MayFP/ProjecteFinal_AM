<?php
//recollim el id del usuari
    $id_user = $_POST["id_user"];

    // echo $id_user;

    //fem la connexio a la bdd
    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");
    
    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        //usem la comanda per eliminar el registre demanat
        $consulta = "DELETE FROM usuari WHERE id_user LIKE '$id_user';";
        $resultat = $connexio->query($consulta);
    }

    //retornem amb missatfe de tot ok
    echo '<script language="javascript">alert("S\'ha eliminat l\'usuari correctament");window.location.href="config.php";</script>';
?>