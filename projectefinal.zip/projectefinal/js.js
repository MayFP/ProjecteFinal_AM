// funcions per fer els contadors de les rutes
function sumar1()
{
    var contador1 = parseInt(document.getElementById('contador1').innerText);

    contador1++;

    document.getElementById('contador1').innerHTML = contador1;
}

function sumar2()
{
    var contador2 = parseInt(document.getElementById('contador2').innerText);

    contador2++;

    document.getElementById('contador2').innerHTML = contador2;
}

function sumar3()
{
    var contador3 = parseInt(document.getElementById('contador3').innerText);

    contador3++;

    document.getElementById('contador3').innerHTML = contador3;
}