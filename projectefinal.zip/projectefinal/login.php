<?php

//recuperem les dades del formulari
    $email = $_POST["email"];
    $password = $_POST["password"];

    echo $email, "<br>", $password, "<br>";

    //fem la conexio a la bdd
    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

        if($connexio->connect_error)
        {
            echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
            $connexio->close();
        }
        else
        {
            //recollim els camps necesaris per fer la validació
            $consulta = "SELECT id_user, correu, password FROM usuari;";
            $resultat = $connexio->query($consulta);
        }

        while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
        {
            // recollim les dades i generem una cookie
            $id_u = $arrayConsulta["id_user"];
            setcookie("id_u", $id_u, time()+600); //caduca en 10 minuts
            $correu = $arrayConsulta["correu"];
            $contrassenya = $arrayConsulta["password"];
            // validem que el usuari existeix
            if($correu == $email && $contrassenya == $password)
            {
                echo '<a>'.$correu.' existeix!</a><br>';
                echo '<a>'.$contrassenya.' existeix!</a><br>';
                echo '<a>'.$email.' entrat!</a><br>';
                echo '<a>'.$password.' entrat!</a><br>';
                // guardem el identificador del usuari logejat en una cookie 
                if($_COOKIE["id_u"] == null || $_COOKIE["id_u"] != $id_u)
                {
                    $_COOKIE["id_u"] = $id_u;
                }
                echo "cookie: ".$_COOKIE["id_u"]."<br>";
                header('Location: index.html');
                echo "redirigeix! <br>";
                break;
            }
            else
            {
                // si no existeix retorna amb un error
                echo "no redirigeix!";
                echo '<a>'.$correu.' no existeix!</a><br>';
                echo '<a>'.$contrassenya.' no existeix!</a><br>';
                echo '<a>'.$email.' entrat!</a><br>';
                echo '<a>'.$password.' entrat!</a><br>';
                echo "cookie: ".$_COOKIE["id_u"]."<br>";
                echo '<script language="javascript">alert("Usuari o contrassenya incorrectes");window.location.href="form.html";</script>';
            }
        }
?>