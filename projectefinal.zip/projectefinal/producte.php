<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Projecte Final</title>
    <link rel="stylesheet" href="producte.css">
    <script type="text/javascript">
      // funció per restar i sumar valors al camp quantitat
      function restar1()
      {
          document.getElementById('contador1').innerHTML = 1;
      }

      function sumar1()
      {
          var contador1 = parseInt(document.getElementById('contador1').innerText);

          contador1++;

          var contador_def = contador1;

          document.getElementById('contador1').innerHTML = contador_def;
      }
    </script>
</head>
<body>
  <!-- barra de navegacio -->
    <nav class="navbar navbar-expand-sm navbar-light">
        <img src="img/logo.png" class="d-inline-block align-top m-3 logo" alt="">
        <a class="navbar-brand" href="index.html">Rutes Moteres</a>
        <button class="navbar-toggler m-3" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" (click)="isShown = !isShown">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" [ngClass]="{'show': isShown}" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" (click)="isShown = false" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="rutes.php">Rutes</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" (click)="isShown = false" href="memories.php">Memories</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="info.php">Info Ruta</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="store.php">Store</a>
            </li>
          </ul>
        </div>
        <a class="nav-link" (click)="isShown = false" href="carro.php">🛒</a>
        <a class="nav-link" (click)="isShown = false" href="config.php">⚙️</a>
        <a class="nav-link" (click)="isShown = false" href="form.html">👤</a>
    </nav>

    <div class="container">
      <?php
// recollim la cookie
        $id_u = $_COOKIE["id_u"];

        // si es null redirijim al formulari de login
        if($id_u == null)
        {
          echo "null!";
          header('Location: form.html');
        }

        // echo $_COOKIE["id_u"];

        $clicat = false;
        $id = $_GET["id"];
        // fem la connexio a la bdd
        $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

        if($connexio->connect_error)
        {
            echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
            $connexio->close();
        }
        else
        {
          // recollim les daes per la sentencia SQL
            $consulta = "SELECT producte.id_prod, producte.nom, producte.descripcio, producte.preu, producte.imatge, producte.id_talla, producte.id_color, talla.descripcio AS tdesc, color.id_color, color.descripcio AS cdesc FROM producte, talla, color WHERE producte.id_talla = talla.id_talla AND producte.id_color = color.id_color AND producte.id_prod LIKE '$id';";
            $resultat = $connexio->query($consulta);

          while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
          {
            // mostrem totes les dades recollides amb el nostre format

            $id_p = $arrayConsulta["id_prod"];
            $nom = $arrayConsulta["nom"];
            $desc = $arrayConsulta["descripcio"];
            $preu = $arrayConsulta["preu"];
            $imatge = $arrayConsulta["imatge"];
            $id_t = $arrayConsulta["id_talla"];
            $nomT = $arrayConsulta["tdesc"];
            $id_c = $arrayConsulta["id_color"];
            $nomC = $arrayConsulta["cdesc"];

            echo '
              <div class="info">
              <div class="foto">
                  <img class="product zoom" src="'.$imatge.'"> <!--Canviar per la imatge recollida de la bdd-->
              </div>
              <div class="configuracions">
                  <h1>'.$nom.'</h1> <!--Canviar per nom del producte de la bdd-->
                  <br>
                  <p>'.$desc.'</p>
              </div>
              </div>
              <div class="descripcio">
                  <label class="talles"><h5>Talles:</h5>
                  ';
                  if($id_t == 1)
                  {
                    echo '
                      <a class="quadradet"><input type="radio" value="'.$id_t.'" name="talla"checked/> '.$nomT.'</a>
                      <a class="quadradet"><input type="radio" value="2" name="talla"disabled/> M</a>
                      <a class="quadradet"><input type="radio" value="3" name="talla"disabled/> L</a>
                      <a class="quadradet"><input type="radio" value="4" name="talla"disabled/> XL</a>
                      <a class="quadradet"><input type="radio" value="5" name="talla"disabled/> U</a>
                      </label> <!--Canviar per les talles del producte de la bdd-->
                    ';
                  }
                  else if($id_t == 2)
                  {
                    echo '
                    <a class="quadradet"><input type="radio" value="1" name="talla"disabled/> S</a>
                    <a class="quadradet"><input type="radio" value="'.$id_t.'" name="talla"checked/> '.$nomT.'</a>
                    <a class="quadradet"><input type="radio" value="3" name="talla"disabled/> L</a>
                    <a class="quadradet"><input type="radio" value="4" name="talla"disabled/> XL</a>
                    <a class="quadradet"><input type="radio" value="5" name="talla"disabled/> U</a>
                    </label> <!--Canviar per les talles del producte de la bdd-->
                    ';
                  }
                  else if($id_t == 3)
                  {
                    echo '
                    <a class="quadradet"><input type="radio" value="1" name="talla"disabled/> S</a>
                    <a class="quadradet"><input type="radio" value="2" name="talla"disabled/> M</a>
                    <a class="quadradet"><input type="radio" value="'.$id_t.'" name="talla"checked/> '.$nomT.'</a>
                    <a class="quadradet"><input type="radio" value="4" name="talla"disabled/> XL</a>
                    <a class="quadradet"><input type="radio" value="5" name="talla"disabled/> U</a>
                    </label> <!--Canviar per les talles del producte de la bdd-->
                    ';
                  }
                  else if($id_t == 4)
                  {
                    echo '
                    <a class="quadradet"><input type="radio" value="1" name="talla"disabled/> S</a>
                    <a class="quadradet"><input type="radio" value="2" name="talla"disabled/> M</a>
                    <a class="quadradet"><input type="radio" value="3" name="talla"disabled/> L</a>
                    <a class="quadradet"><input type="radio" value="'.$id_t.'" name="talla"checked/> '.$nomT.'</a>
                    <a class="quadradet"><input type="radio" value="5" name="talla"disabled/> U</a>
                    </label> <!--Canviar per les talles del producte de la bdd-->
                    ';
                  }
                  else if($id_t == 5)
                  {
                    echo '
                    <a class="quadradet"><input type="radio" value="1" name="talla"disabled/> S</a>
                    <a class="quadradet"><input type="radio" value="2" name="talla"disabled/> M</a>
                    <a class="quadradet"><input type="radio" value="3" name="talla"disabled/> L</a>
                    <a class="quadradet"><input type="radio" value="4" name="talla"disabled/> XL</a>
                    <a class="quadradet"><input type="radio" value="'.$id_t.'" name="talla"checked/> '.$nomT.'</a>
                    </label> <!--Canviar per les talles del producte de la bdd-->
                    ';
                  }

                  if($id_c == 1)
                  {
                    echo '
                    <br>
                    <label class="colors"><h5>Colors:</h5>
                      <a class="quadradet"><input type="radio" value="'.$id_c.'" name="color"checked/> 🟥</a>
                      <a class="quadradet"><input type="radio" value="2" name="color"disabled/> 🟦</a>
                      <a class="quadradet"><input type="radio" value="3" name="color"disabled/> ⬛️</a>
                      <a class="quadradet"><input type="radio" value="4" name="color"disabled/> ​🟪</a>
                      <a class="quadradet"><input type="radio" value="5" name="color"disabled/> ⬜️</a>
                    </label> <!--Canviar pels colors del producte de la bdd-->
                    ';
                  }
                  else if($id_c == 2)
                  {
                    echo '
                    <br>
                    <label class="colors"><h5>Colors:</h5>
                      <a class="quadradet"><input type="radio" value="1" name="color"disabled/> 🟥</a>
                      <a class="quadradet"><input type="radio" value="'.$id_c.'" name="color"checked/> 🟦</a>
                      <a class="quadradet"><input type="radio" value="3" name="color"disabled/> ⬛️</a>
                      <a class="quadradet"><input type="radio" value="4" name="color"disabled/> ​🟪</a>
                      <a class="quadradet"><input type="radio" value="5" name="color"disabled/> ⬜️</a>
                    </label> <!--Canviar pels colors del producte de la bdd-->
                    ';
                  }
                  else if($id_c == 3)
                  {
                    echo '
                    <br>
                    <label class="colors"><h5>Colors:</h5>
                      <a class="quadradet"><input type="radio" value="1" name="color"disabled/> 🟥</a>
                      <a class="quadradet"><input type="radio" value="2" name="color"disabled/> 🟦</a>
                      <a class="quadradet"><input type="radio" value="'.$id_c.'" name="color"checked/> ⬛️</a>
                      <a class="quadradet"><input type="radio" value="4" name="color"disabled/> ​🟪</a>
                      <a class="quadradet"><input type="radio" value="5" name="color"disabled/> ⬜️</a>
                    </label> <!--Canviar pels colors del producte de la bdd-->
                    ';
                  }
                  else if($id_c == 4)
                  {
                    echo '
                    <br>
                    <label class="colors"><h5>Colors:</h5>
                      <a class="quadradet"><input type="radio" value="1" name="color"disabled/> 🟥</a>
                      <a class="quadradet"><input type="radio" value="2" name="color"disabled/> 🟦</a>
                      <a class="quadradet"><input type="radio" value="3" name="color"disabled/> ⬛️</a>
                      <a class="quadradet"><input type="radio" value="'.$id_c.'" name="color"checked/> ​🟪</a>
                      <a class="quadradet"><input type="radio" value="5" name="color"disabled/> ⬜️</a>
                    </label> <!--Canviar pels colors del producte de la bdd-->
                    ';
                  }
                  else if($id_c == 5)
                  {
                    echo '
                    <br>
                    <label class="colors"><h5>Colors:</h5>
                      <a class="quadradet"><input type="radio" value="1" name="color"disabled/> 🟥</a>
                      <a class="quadradet"><input type="radio" value="2" name="color"disabled/> 🟦</a>
                      <a class="quadradet"><input type="radio" value="3" name="color"disabled/> ⬛️</a>
                      <a class="quadradet"><input type="radio" value="4" name="color"disabled/> ​🟪</a>
                      <a class="quadradet"><input type="radio" value="'.$id_c.'" name="color"checked/> ⬜️</a>
                    </label> <!--Canviar pels colors del producte de la bdd-->
                    ';
                  }

                  $id_usu = "'".$id_u."'";

                  echo '
                  <br>
                  <label><b>Quantitat: </b></label>
                  <div class="quantitat">
                    <button class="btns" onclick="sumar1()" id="mes">+</button>
                    <label id="contador1">1</label>
                    <button class="btnr" onclick="restar1()">-</button>
                  </div>
                  <br>
                  <br>
                  <button type="submit" class="preu"><img src="img/carrito.png"> <a class="carro" href="afegirprodcarro.php?id_u='.$id_usu.'&id_p='.$id_p.'&quantitat=1">'.$preu.'€ </a></button> <!--Canviar pel preu del producte de la bdd-->
              </div>
            ';
          }
        }
      ?>
    </div>
<!--  footer -->
    <div class="contain">
        <div class="banner">
            <p>©Rutes Moteres. Tots els drets reservats - Alex Montero i Maria Ferrer. </p>
        </div>
        <div class="links">
            <a href="https://t.me/+D4mgYwsk4_JjOTc0"><img src="img/telegram.png" class="telegram"></a>
            <a href="https://twitter.com/"><img src="img/twitter.png"  class="twitter"></a>
            <a href="https://www.facebook.com/"><img src="img/facebook.png" class="facebook"></a>
            <a href="https://www.instagram.com/"><img src="img/instagram.png" class="instagram"></a>
        </div>
    </div>
</body>
</html>