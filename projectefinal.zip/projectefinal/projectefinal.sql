-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-06-2022 a las 00:30:24
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `projectefinal`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carro`
--

CREATE TABLE `carro` (
  `id_user` varchar(255) NOT NULL,
  `id_prod` int(11) NOT NULL,
  `quantitat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carro`
--

INSERT INTO `carro` (`id_user`, `id_prod`, `quantitat`) VALUES
('05/12/2022-05:25:40', 13, 1),
('05/12/2022-05:25:40', 32, 1),
('05/12/2022-05:25:40', 45, 1),
('05/12/2022-05:25:40', 46, 1),
('05/12/2022-05:25:40', 52, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color`
--

CREATE TABLE `color` (
  `id_color` int(11) NOT NULL,
  `descripcio` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `color`
--

INSERT INTO `color` (`id_color`, `descripcio`) VALUES
(1, 'vermell'),
(2, 'blau'),
(3, 'negre'),
(4, 'lila'),
(5, 'blanc');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `color_producte`
--

CREATE TABLE `color_producte` (
  `id_prod` int(11) DEFAULT NULL,
  `id_color` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producte`
--

CREATE TABLE `producte` (
  `id_prod` int(11) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `descripcio` varchar(200) DEFAULT NULL,
  `preu` float DEFAULT NULL,
  `imatge` varchar(100) DEFAULT NULL,
  `id_talla` int(11) DEFAULT NULL,
  `id_color` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `producte`
--

INSERT INTO `producte` (`id_prod`, `nom`, `descripcio`, `preu`, `imatge`, `id_talla`, `id_color`) VALUES
(1, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaV.jpg', 1, 1),
(2, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaB.jpg', 1, 2),
(3, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaN.jpg', 1, 3),
(4, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaR.jpg', 1, 4),
(5, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaBL.jpg', 1, 5),
(6, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaV.jpg', 2, 1),
(7, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaB.jpg', 2, 2),
(8, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaN.jpg', 2, 3),
(9, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaR.jpg', 2, 4),
(10, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaBL.jpg', 2, 5),
(11, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaV.jpg', 3, 1),
(12, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaB.jpg', 3, 2),
(13, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaN.jpg', 3, 3),
(14, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaR.jpg', 3, 4),
(15, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaBL.jpg', 3, 5),
(16, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaV.jpg', 4, 1),
(17, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaB.jpg', 4, 2),
(18, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaN.jpg', 4, 3),
(19, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaR.jpg', 4, 4),
(20, 'camiseta', 'camiseta amb el logo del club', 19.99, 'assets/img/camisetaBL.jpg', 4, 5),
(21, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaV.jpg', 1, 1),
(22, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaB.jpg', 1, 2),
(23, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaN.jpg', 1, 3),
(24, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaR.jpg', 1, 4),
(25, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaBL.jpg', 1, 5),
(26, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaV.jpg', 2, 1),
(27, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaB.jpg', 2, 2),
(28, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaN.jpg', 2, 3),
(29, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaR.jpg', 2, 4),
(30, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaBL.jpg', 2, 5),
(31, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaV.jpg', 3, 1),
(32, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaB.jpg', 3, 2),
(33, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaN.jpg', 3, 3),
(34, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaR.jpg', 3, 4),
(35, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaBL.jpg', 3, 5),
(36, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaV.jpg', 4, 1),
(37, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaB.jpg', 4, 2),
(38, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaN.jpg', 4, 3),
(39, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaR.jpg', 4, 4),
(40, 'sudadera', 'sudadera amb el logo del club', 34.99, 'assets/img/sudaderaBL.jpg', 4, 5),
(41, 'gorra', 'gorra amb el logo del club', 14.99, 'assets/img/gorraV.jpg', 5, 1),
(42, 'gorra', 'gorra amb el logo del club', 14.99, 'assets/img/gorraB.jpg', 5, 2),
(43, 'gorra', 'gorra amb el logo del club', 14.99, 'assets/img/gorraN.jpg', 5, 3),
(44, 'gorra', 'gorra amb el logo del club', 14.99, 'assets/img/gorraR.jpg', 5, 4),
(45, 'gorra', 'gorra amb el logo del club', 14.99, 'assets/img/gorraBL.jpg', 5, 5),
(46, 'clauer2', 'clauer cinta amb el logo', 9.99, 'assets/img/clauer2V.jpg', 5, 1),
(47, 'clauer2', 'clauer cinta amb el logo', 9.99, 'assets/img/clauer2B.jpg', 5, 2),
(48, 'clauer2', 'clauer cinta amb el logo', 9.99, 'assets/img/clauer2N.jpg', 5, 3),
(49, 'clauer2', 'clauer cinta amb el logo', 9.99, 'assets/img/clauer2R.jpg', 5, 4),
(50, 'clauer2', 'clauer cinta amb el logo', 9.99, 'assets/img/clauer2BL.jpg', 5, 5),
(51, 'clauer1', 'clauer amb el logo del club', 11.99, 'assets/img/clauer1.jpg', 5, 3),
(52, 'enganxina', 'enganxina amb el logo del club', 4.99, 'assets/img/enganxina.jpg', 5, 5),
(53, 'prova', 'prova prova prova', 0, 'assets/img/ruta2.jpg', 5, 2),
(54, 'alex', 'sdwdwd', 11, 'assets/img/bufet.jpg', 5, 3),
(55, 'marc', 'tonto', 1000, 'assets/img/bufet.jpg', 4, 5),
(56, 'nico', 'si', 11, 'assets/img/bufet.jpg', 5, 4),
(57, 'may', 'si', 1, 'assets/img/imagen_2022-06-01_182346466.png', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ruta`
--

CREATE TABLE `ruta` (
  `id_ruta` int(11) NOT NULL,
  `foto_ruta` varchar(100) DEFAULT NULL,
  `mapa` longtext DEFAULT NULL,
  `descripcio` varchar(200) DEFAULT NULL,
  `dia` date DEFAULT NULL,
  `hora_sortida` time DEFAULT NULL,
  `hora_arribada` time DEFAULT NULL,
  `lloc_sortida` varchar(50) DEFAULT NULL,
  `lloc_arribada` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ruta`
--

INSERT INTO `ruta` (`id_ruta`, `foto_ruta`, `mapa`, `descripcio`, `dia`, `hora_sortida`, `hora_arribada`, `lloc_sortida`, `lloc_arribada`) VALUES
(1, 'img/ruta1.jpg ', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m27!1m12!1m3!1d47467.72878187163!2d2.8253446242268203!3d41.96306862573261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m12!3e0!4m4!1s0x12bae0d3e2b9ece1%3A0x5e50d6bc3962bc91!3m2!1d41.960426!2d2.8111995!4m5!1s0x12bae531d1f9e3e9%3A0x65f3c7e3f4b544b5!2sEls%20%C3%81ngels%2C%20GIV-6703%2C%2017462%2C%20Girona!3m2!1d41.984724899999996!2d2.909007!5e0!3m2!1ses!2ses!4v1647617670350!5m2!1ses!2ses\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe> ', 'Ruta els Àngels', '2022-07-16', '10:00:00', '10:45:00', 'Decathlon Girona', 'Mirador dels Àngels'),
(2, 'img/ruta2.jpg ', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m40!1m12!1m3!1d94835.43516232763!2d2.585446399488564!3d42.030155022303056!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m25!3e0!4m5!1s0x12bad9629d707137%3A0xae23d1476dab100d!2sBar%20Can%20Jans%2C%20Pla%C3%A7a%20Don%20Manuel%2C%20Bonmat%C3%AD!3m2!1d41.968163499999996!2d2.6707337!4m5!1s0x12bacff6b3915e0b%3A0xd97207dabfe4aad0!2sSant%20Esteve%20de%20Ll%C3%A9mena!3m2!1d42.0632652!2d2.6149442!4m5!1s0x12bacdfd8ef1391b%3A0x48733bc17e52429!2sLes%20Planes%20d&#39;Hostoles!3m2!1d42.0563863!2d2.5383647!4m5!1s0x12bad0615cf5c759%3A0x400fae021a46590!2sAmer!3m2!1d42.0104174!2d2.6028035999999997!5e0!3m2!1ses!2ses!4v1648735478997!5m2!1ses!2ses\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 'Ruta de les Serres fins Amer', '2022-07-30', '11:00:00', '12:00:00', 'Bar Can Jans', 'Amer'),
(3, 'img/ruta3.jpg ', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d95009.59194543104!2d2.576326147201459!3d41.91328926499022!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e0!4m5!1s0x12bae754d85c600b%3A0x44c7d83a8f48f834!2sEspai%20Giron%C3%A8s%2C%20Cam%C3%AD%20dels%20Carlins%2C%2010%2C%2017190%20Salt%2C%20Girona!3m2!1d41.9664929!2d2.7815772!4m5!1s0x12bb2a70bd65df2d%3A0xd14c5c9834062a51!2sSant%20Hilari%20Sacalm!3m2!1d41.8784012!2d2.5121713999999997!5e0!3m2!1ses!2ses!4v1648735685723!5m2!1ses!2ses\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 'Ruta a Sant Hilari ', '2022-08-15', '11:00:00', '12:00:00', 'Espai Gironès', 'Sant Hilari Sacalm');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `talla`
--

CREATE TABLE `talla` (
  `id_talla` int(11) NOT NULL,
  `descripcio` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `talla`
--

INSERT INTO `talla` (`id_talla`, `descripcio`) VALUES
(1, 's'),
(2, 'm'),
(3, 'l'),
(4, 'xl'),
(5, 'u');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `talla_producte`
--

CREATE TABLE `talla_producte` (
  `id_prod` int(11) DEFAULT NULL,
  `id_talla` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuari`
--

CREATE TABLE `usuari` (
  `id_user` varchar(20) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `correu` varchar(25) DEFAULT NULL,
  `imatge` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuari`
--

INSERT INTO `usuari` (`id_user`, `nom`, `password`, `correu`, `imatge`) VALUES
('03/17/2022-05:41:40', 'amope02', '123456', 'alexmope02@gmail.com', 'img/cli.jpg'),
('03/18/2022-03:14:13', 'may_tcw', '1234567', 'ilovebikes121@gmail.com', 'img/quesos.jpg'),
('03/24/2022-03:53:30', 'joan1313', '12345678', 'joan1313@gmail.com', 'img/hacecalor.jpg'),
('05/12/2022-05:08:10', 'xefa', '123456789', 'xefa01@gmail.com', 'img/c3.jpg'),
('05/12/2022-05:25:40', 'ruben', '123', 'ruben@gmail.com', 'img/ruben.jpg'),
('05/30/2022-10:13:29', 'Any', 'alexymarc', 'anyblue82@hotmail.es', 'img/c2.jpg'),
('admin', 'admin', 'admin', 'admin@gmail.com', 'img/admin_.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carro`
--
ALTER TABLE `carro`
  ADD PRIMARY KEY (`id_user`,`id_prod`);

--
-- Indices de la tabla `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id_color`);

--
-- Indices de la tabla `color_producte`
--
ALTER TABLE `color_producte`
  ADD KEY `id_color` (`id_color`),
  ADD KEY `id_prod` (`id_prod`);

--
-- Indices de la tabla `producte`
--
ALTER TABLE `producte`
  ADD PRIMARY KEY (`id_prod`);

--
-- Indices de la tabla `ruta`
--
ALTER TABLE `ruta`
  ADD PRIMARY KEY (`id_ruta`);

--
-- Indices de la tabla `talla`
--
ALTER TABLE `talla`
  ADD PRIMARY KEY (`id_talla`);

--
-- Indices de la tabla `talla_producte`
--
ALTER TABLE `talla_producte`
  ADD KEY `id_talla` (`id_talla`),
  ADD KEY `id_prod` (`id_prod`);

--
-- Indices de la tabla `usuari`
--
ALTER TABLE `usuari`
  ADD PRIMARY KEY (`id_user`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `color_producte`
--
ALTER TABLE `color_producte`
  ADD CONSTRAINT `color_producte_ibfk_1` FOREIGN KEY (`id_color`) REFERENCES `color` (`id_color`),
  ADD CONSTRAINT `color_producte_ibfk_2` FOREIGN KEY (`id_prod`) REFERENCES `producte` (`id_prod`);

--
-- Filtros para la tabla `talla_producte`
--
ALTER TABLE `talla_producte`
  ADD CONSTRAINT `talla_producte_ibfk_1` FOREIGN KEY (`id_talla`) REFERENCES `talla` (`id_talla`),
  ADD CONSTRAINT `talla_producte_ibfk_2` FOREIGN KEY (`id_prod`) REFERENCES `producte` (`id_prod`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
