<?php
//aixo es per recollir la imatge de la carpeta temporal a una fisica del servidor i les dades del formulari
    $upload_dir = 'C:\xampp\htdocs\projectefinal\img';
    $dir_intern = 'img';
    $id = date('m/d/Y-h:i:s', time());
    $email = $_POST["email"];
    $password = $_POST["password"];
    $nom = $_POST["nom"];
    $photo_ruta = $_FILES['photo']['tmp_name'];
    $photo_name = $_FILES["photo"]["name"];
    $photo = "$upload_dir/$photo_name";
    $photo_bdd = "$dir_intern/$photo_name";
    $espotafegir = false;

    move_uploaded_file($photo_ruta, $photo);

//fem la connexio a la bdd
    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

            if($connexio->connect_error)
            {
                echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
                $connexio->close();
            }
            else
            {
                //recollim el nom d'usuari de la bdd
                $consulta = "SELECT nom FROM usuari;";
                $resultat = $connexio->query($consulta);
            }

            while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
            {
                //comprovem si existeix
                $usuari = $arrayConsulta["nom"];
                if($usuari == $nom)
                {
                    echo '<script language="javascript">alert("L\'usuari ja existeix!");window.location.href="formlogin.html";</script>';
                    $connexio->close();
                }
                else
                {
                    $espotafegir = true;
                }
                echo '<a>'.$usuari.'</a><br>';
            }

            //si exsisteix llavors inserim les dades a la bdd.
            if($espotafegir == true)
            {
                $consulta2 = "INSERT INTO usuari (id_user, nom, correu, password, imatge) VALUES ('$id', '$nom', '$email', '$password', '$photo_bdd');";
                $resultat2 = $connexio->query($consulta2);
                header('Location: form.html');
            }

    header("Location: form.html");
    
?>