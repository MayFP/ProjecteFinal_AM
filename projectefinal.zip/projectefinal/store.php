<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="store.css">
    <title>Projecte Final</title>
</head>
<body>
  <!-- barra de navegació -->
    <nav class="navbar navbar-expand-sm navbar-light">
        <img src="img/logo.png" class="d-inline-block align-top m-3 logo" alt="">
        <a class="navbar-brand" href="index.html">Rutes Moteres</a>
        <button class="navbar-toggler m-3" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" (click)="isShown = !isShown">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" [ngClass]="{'show': isShown}" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" (click)="isShown = false" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="rutes.php">Rutes</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" (click)="isShown = false" href="memories.php">Memories</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="info.php">Info Ruta</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" (click)="isShown = false" href="store.php">Store</a>
            </li>
          </ul>
        </div>
        <a class="nav-link" (click)="isShown = false" href="carro.php">🛒</a>
        <a class="nav-link" (click)="isShown = false" href="config.php">⚙️</a>
        <a class="nav-link" (click)="isShown = false" href="form.html">👤</a>
    </nav>

    <div class="container">
      <?php 

// comprovem que no sigui null la cookie i si es null iniciem com a guest, sino com a usuari registrat
        if(isset($_COOKIE["id_u"]))
        {
          $id_u = $_COOKIE["id_u"];
        }
        else
        {
          $id_u = 'guest';
        }

        // fem la connexio i recollim les dades
        $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");

        if($connexio->connect_error)
        {
            echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
            $connexio->close();
        }
        else
        {
            $consulta = "SELECT producte.id_prod, producte.nom, producte.preu, producte.imatge, producte.id_talla, talla.descripcio AS tdesc FROM producte, talla WHERE producte.id_talla = talla.id_talla;";
            $resultat = $connexio->query($consulta);
        }

        // mostrem les dades recollides
        while($arrayConsulta = $resultat->fetch_array(MYSQLI_BOTH))
        {

          $id = $arrayConsulta["id_prod"];
          $nom = $arrayConsulta["nom"];
          $preu = $arrayConsulta["preu"];
          $imatge = $arrayConsulta["imatge"];
          $nomT = $arrayConsulta["tdesc"];

          echo '
            <a href="producte.php?id='.$id.'" class="btt">
              <div class="producte">
                <br>
                <img src="'.$imatge.'"> <!--canviar per imatge del producte!-->
                <div class="prod">
                  <p>'.$nom.' - Talla: '.$nomT.'</p> <!--canviar per nom del producte!-->
                  <p>'.$preu.'€</p> <!--canviar per preu del producte!-->
                </div>
              </div>
            </a>
          ';
        }

        // en cas de ser admin mostrarem aquest altre apartat
        if($id_u == 'admin')
        {
          echo '
            <a href="add.html" class="btt">
              <div class="producte">
                <br>
                <img src="img/add.png"> <!--canviar per imatge del producte!-->
                <div class="prod">
                  <p>Afegir un nou producte</p> <!--canviar per nom del producte!-->
                </div>
              </div>
            </a>
          ';
        }
      ?>

    </div>
<!--  footer -->
    <div class="contain">
        <div class="banner">
            <p>©Rutes Moteres. Tots els drets reservats - Alex Montero i Maria Ferrer. </p>
        </div>
        <div class="links">
            <a href="https://t.me/+D4mgYwsk4_JjOTc0"><img src="img/telegram.png" class="telegram"></a>
            <a href="https://twitter.com/"><img src="img/twitter.png"  class="twitter"></a>
            <a href="https://www.facebook.com/"><img src="img/facebook.png" class="facebook"></a>
            <a href="https://www.instagram.com/"><img src="img/instagram.png" class="instagram"></a>
        </div>
    </div>
</body>
</html>