<?php
    $id_u = $_COOKIE["id_u"];

    echo $id_u;

    $connexio = new mysqli("localhost:3306", "alex", "123456", "projectefinal");
    
    if($connexio->connect_error)
    {
        echo "Ha ocurragut un error, numero d'error: ", $connexio->connect_errno, "<br>";
        $connexio->close();
    }
    else
    {
        $consulta = "DELETE FROM carro WHERE id_user LIKE '$id_u';";
        $resultat = $connexio->query($consulta);
        echo '<script language="javascript">alert("Has buidat el teu carro correctament!");window.location.href="carro.php";</script>';
    }
?>